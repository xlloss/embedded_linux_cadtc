# gpio-sysfs-demo
Example Code for Using GPIO sysfs Interface in Linux
